<?php
$host = "localhost";
$username = "root";
$password = "Manisha@75999";
$database = "employees_db";


$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT first_name, last_name, department_id, department_name FROM employees";

$result = $conn->query($sql);


if ($result->num_rows > 0) {
   
    while ($row = $result->fetch_assoc()) {
        echo "Name: " . $row["first_name"] . " " . $row["last_name"] . "<br>";
        echo "Department ID: " . $row["department_id"] . "<br>";
        echo "Department Name: " . $row["department_name"] . "<br><br>";
    }
} else {
    echo "No results found.";
}


$conn->close();
?>
