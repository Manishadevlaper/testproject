<?php
$rows = 7;

for ($i = 1; $i <= $rows; $i++) {
  // Print the first half of the pattern
  for ($j = 1; $j <= $i; $j++) {
    echo "* ";
  }
  echo "<br>";
}

for ($i = $rows - 1; $i >= 1; $i--) {
  // Print the second half of the pattern
  for ($j = 1; $j <= $i; $j++) {
    echo "* ";
  }
  echo "<br>";
}
?>
